﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Messages
{
    public class TextMessage
    {
        public string Text { get; set; }
    }
}
